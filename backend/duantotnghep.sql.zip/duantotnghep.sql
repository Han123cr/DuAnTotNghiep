-- -------------------------
-- CƠ SỞ DỮ LIỆU QUẢN LÝ NHÀ HÀNG
-- -------------------------

-- Bảng quản trị viên (admin)
CREATE TABLE admin (
    loginName VARCHAR(255),                      -- Tên đăng nhập
    password VARCHAR(255) NOT NULL                -- Mật khẩu
);

-- Bảng nhân viên (staffs)
CREATE TABLE staffs (
    staffID INT AUTO_INCREMENT PRIMARY KEY,      -- ID nhân viên
    name VARCHAR(255) NOT NULL,                  -- Tên nhân viên
    avatar VARCHAR(255),                          -- Hình đại diện
    loginName VARCHAR(255),                       -- Tên đăng nhập
    password VARCHAR(255) NOT NULL,               -- Mật khẩu
    status ENUM('working', 'inactive') DEFAULT 'working', -- Trạng thái làm việc
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP   -- Ngày tạo tài khoản
);

-- Bảng khách hàng (customers)
CREATE TABLE customers (
    customerID INT AUTO_INCREMENT PRIMARY KEY,  -- ID khách hàng
    name VARCHAR(255) NOT NULL,                  -- Tên khách hàng
    avatar VARCHAR(255),                          -- Hình đại diện
    email VARCHAR(255) UNIQUE,                   -- Email (duy nhất)
    phoneNumber VARCHAR(15) UNIQUE,              -- Số điện thoại (duy nhất)
    password VARCHAR(255) NOT NULL,              -- Mật khẩu
    status ENUM('active', 'blocked') DEFAULT 'active', -- Trạng thái tài khoản
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP, -- Ngày tạo tài khoản
    CHECK (email IS NOT NULL OR phoneNumber IS NOT NULL)  -- Email hoặc số điện thoại phải được cung cấp
);

-- Bảng địa chỉ (addresses)
CREATE TABLE addresses (
    addressID INT AUTO_INCREMENT PRIMARY KEY,    -- ID địa chỉ
    address TEXT NOT NULL,                       -- Địa chỉ
    recipientPhone VARCHAR(15) NOT NULL,         -- Số điện thoại người nhận
    recipientName VARCHAR(255) NOT NULL,         -- Tên người nhận
    customerID INT,                              -- Khóa ngoại tới bảng customers
    FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE
);

-- Bảng vouchers (voucher)
CREATE TABLE vouchers (
    voucherID INT AUTO_INCREMENT PRIMARY KEY,   -- ID voucher
    code VARCHAR(50) NOT NULL,                  -- Mã voucher
    discount DECIMAL(10, 2) NOT NULL,           -- Phần trăm hoặc số tiền giảm giá
    type ENUM('order', 'table') NOT NULL,       -- Loại voucher: dành cho đặt hàng ('order') hoặc đặt bàn ('table')
    expirationDate DATE,                        -- Ngày hết hạn
    status ENUM('active', 'expired') DEFAULT 'active', -- Trạng thái voucher (active, expired)
    usageLimit INT DEFAULT 1,                   -- Giới hạn số lần sử dụng
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP  -- Ngày tạo voucher
);

-- Bảng người dùng sử dụng voucher (customerUseVouchers)
CREATE TABLE customerUseVouchers(
    customerUseVoucherID INT AUTO_INCREMENT PRIMARY KEY,
    customerID INT NOT NULL,                 -- ID người dùng
    voucherID INT NOT NULL,              -- ID voucher
    usedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Thời điểm sử dụng voucher
    FOREIGN KEY (customerID) REFERENCES customers(customerID),
    FOREIGN KEY (voucherID) REFERENCES vouchers(voucherID)
);

-- Bảng phương thức thanh toán (paymentMethods)
CREATE TABLE paymentMethods (
    paymentMethodID INT AUTO_INCREMENT PRIMARY KEY,   -- ID phương thức thanh toán
    methodName VARCHAR(255) NOT NULL                  -- Tên phương thức thanh toán
);

-- Bảng chi nhánh (branches)
CREATE TABLE branches (
    branchID INT AUTO_INCREMENT PRIMARY KEY,      -- ID chi nhánh
    branchName VARCHAR(255) NOT NULL,            -- Tên chi nhánh
    address VARCHAR(255),                         -- Địa chỉ chi nhánh
    branchPhone VARCHAR(15) UNIQUE                -- Số điện thoại chi nhánh (duy nhất)
);

-- Bảng menu (menus)
CREATE TABLE menus (
    menuID INT AUTO_INCREMENT PRIMARY KEY,          -- ID menu
    menuName VARCHAR(255) NOT NULL,                 -- Tên menu
    menuImage VARCHAR(255) NOT NULL                 -- Hình ảnh menu
);

-- Bảng món ăn (menuItems)
CREATE TABLE menuItems (
    menuItemID INT AUTO_INCREMENT PRIMARY KEY,      -- ID món ăn
    itemName VARCHAR(255) NOT NULL,                 -- Tên món ăn
    description TEXT,                               -- Mô tả món ăn
    price DECIMAL(10, 2) NOT NULL,                  -- Giá món ăn
    discount DECIMAL(10, 2),                        -- Giá giảm (nếu có)
    menuID INT,                                     -- Khóa ngoại tới bảng menus
    FOREIGN KEY (menuID) REFERENCES menus(menuID) ON DELETE CASCADE
);

-- Bảng hình ảnh món ăn (menuItemImages)
CREATE TABLE menuItemImages (
    imageID INT AUTO_INCREMENT PRIMARY KEY,          -- ID hình ảnh
    imagePath VARCHAR(255) NOT NULL,                 -- Đường dẫn hình ảnh
    description TEXT,                               -- Mô tả hình ảnh
    menuItemID INT,                                 -- Khóa ngoại tới bảng menuItems
    FOREIGN KEY (menuItemID) REFERENCES menuItems(menuItemID) ON DELETE CASCADE
);

-- Bảng món ăn yêu thích (favoriteFoods)
CREATE TABLE favoriteFoods (
    favoriteFoodID INT AUTO_INCREMENT PRIMARY KEY,         -- ID của bản ghi
    customerID INT NOT NULL,                       -- ID của người dùng
    menuItemID INT NOT NULL,                       -- ID của món ăn
    addedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Thời gian thêm món ăn vào danh sách yêu thích
    FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE,
    FOREIGN KEY (menuItemID) REFERENCES menuItems(menuItemID) ON DELETE CASCADE
);

-- Bảng bàn (tables)
CREATE TABLE tables (
    tableID INT AUTO_INCREMENT PRIMARY KEY,       -- ID bàn
    tableNumber INT NOT NULL,                     -- Số bàn
    tableStatus ENUM('open', 'close', 'wait') NOT NULL,  -- Trạng thái bàn
    branchID INT,                                 -- Khóa ngoại tới bảng branches
    FOREIGN KEY (branchID) REFERENCES branches(branchID)
);

-- Bảng đặt bàn (tableOrders)
CREATE TABLE tableOrders (
    tableOrderID INT AUTO_INCREMENT PRIMARY KEY,  -- ID đơn đặt bàn
    createdAt DATETIME NOT NULL,                  -- Thời gian tạo đặt chỗ
    arrivalTime DATETIME NOT NULL,                -- Thời gian đến
    numberOfPeople INT NOT NULL,                  -- Số lượng người
    notes TEXT,                                   -- Yêu cầu đặc biệt
    bookerName VARCHAR(255) NOT NULL,            -- Tên người đặt
    bookerPhoneNumber VARCHAR(15) NOT NULL,      -- Số điện thoại người đặt
    tableNumber INT NOT NULL,                     -- Số bàn
    tableOrderStatus ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending', -- Trạng thái đặt chỗ
    transactionCode TEXT,                         -- Mã giao dịch
    customerID INT,                              -- Khóa ngoại tới khách hàng
    branchID INT,                                -- Khóa ngoại tới chi nhánh
    tableID INT,                                 -- Khóa ngoại tới bàn
    paymentMethodID INT,                         -- Khóa ngoại tới bảng paymentMethod
    voucherID INT,                               -- Khóa ngoại tới bảng vouchers
    deposit DECIMAL(10, 2) NOT NULL,   -- Số tiền đặt cọc
    FOREIGN KEY (branchID) REFERENCES branches(branchID) ON DELETE CASCADE,
    FOREIGN KEY (voucherID) REFERENCES vouchers(voucherID) ON DELETE CASCADE,
    FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE,
    FOREIGN KEY (tableID) REFERENCES tables(tableID) ON DELETE CASCADE,
    FOREIGN KEY (paymentMethodID) REFERENCES paymentMethods(paymentMethodID) ON DELETE SET NULL
);

-- Bảng đặt bàn chi tiết (tableAndOrders)
CREATE TABLE tableAndOrders (
    tableAndOrdersID INT AUTO_INCREMENT PRIMARY KEY,             -- ID
    tableOrderID INT,                              -- Khóa ngoại tới bảng đặt bàn
    tableID INT,                                   -- Khóa ngoại tới bàn
    FOREIGN KEY (tableOrderID) REFERENCES tableOrders(tableOrderID),
    FOREIGN KEY (tableID) REFERENCES tables(tableID)
);

-- Bảng hóa đơn đặt bàn (tableBills)
CREATE TABLE tableBills (
    tableBillID INT AUTO_INCREMENT PRIMARY KEY,    -- ID hóa đơn
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Ngày tạo hóa đơn
    totalAmount DECIMAL(10, 2) NOT NULL,         -- Tổng giá trị hóa đơn
    remainingAmount DECIMAL(10, 2) NOT NULL, -- Số tiền còn lại
    paymentMethodID INT,                          -- Khóa ngoại tới bảng phương thức thanh toán
    tableOrderID INT,                             -- Khóa ngoại tới bảng đặt bàn
    FOREIGN KEY (tableOrderID) REFERENCES tableOrders(tableOrderID) ON DELETE CASCADE,
    FOREIGN KEY (paymentMethodID) REFERENCES paymentMethods(paymentMethodID) ON DELETE SET NULL
);

-- Bảng chi tiết hóa đơn (tableBillDetails)
CREATE TABLE tableBillDetails (
    tableBillDetailID INT AUTO_INCREMENT PRIMARY KEY, -- ID chi tiết hóa đơn
    quantity INT NOT NULL,                           -- Số lượng món ăn
    price DECIMAL(10, 2) NOT NULL,                   -- Giá món ăn
    discount DECIMAL(10, 2),                         -- Giảm giá (nếu có)
    total DECIMAL(10, 2) NOT NULL,                   -- Tổng giá sau khi tính
    tableBillID INT,                                 -- Khóa ngoại tới bảng hóa đơn
    menuItemID INT,                                  -- Khóa ngoại tới bảng menuItems
    FOREIGN KEY (tableBillID) REFERENCES tableBills(tableBillID) ON DELETE CASCADE,
    FOREIGN KEY (menuItemID) REFERENCES menuItems(menuItemID) ON DELETE CASCADE
);

-- Bảng chi tiết giỏ hàng (carts)
CREATE TABLE carts (
    cartItemID INT AUTO_INCREMENT PRIMARY KEY,        -- ID chi tiết giỏ hàng
    quantity INT NOT NULL,                            -- Số lượng món ăn
    menuItemID INT,                                   -- Khóa ngoại tới bảng menuItems
    customerID INT,                                  -- Khóa ngoại tới bảng customers
    FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE,
    FOREIGN KEY (menuItemID) REFERENCES menuItems(menuItemID) ON DELETE CASCADE
);

-- Bảng đơn hàng (orders)
CREATE TABLE orders (
    orderID INT AUTO_INCREMENT PRIMARY KEY,          -- ID đơn hàng
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,   -- Ngày đặt hàng
    status VARCHAR(50) NOT NULL,                     -- Trạng thái đơn hàng
    totalAmount DECIMAL(10, 2) NOT NULL,            -- Tổng giá trị đơn hàng
    transactionCode TEXT,                            -- Mã giao dịch
    paymentMethodID INT,                             -- Khóa ngoại tới bảng paymentMethod
    customerID INT,                                  -- Khóa ngoại tới bảng customers
    addressID INT,                                   -- Khóa ngoại tới bảng addresses
    voucherID INT,                               -- Khóa ngoại tới bảng vouchers
    FOREIGN KEY (voucherID) REFERENCES vouchers(voucherID) ON DELETE CASCADE,
    FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE,
    FOREIGN KEY (addressID) REFERENCES addresses(addressID) ON DELETE SET NULL,
    FOREIGN KEY (paymentMethodID) REFERENCES paymentMethods(paymentMethodID) ON DELETE SET NULL
);

-- Bảng chi tiết đơn hàng (orderDetails)
CREATE TABLE orderDetails (
    orderDetailID INT AUTO_INCREMENT PRIMARY KEY,     -- ID chi tiết đơn hàng
    quantity INT NOT NULL,                           -- Số lượng món ăn
    price DECIMAL(10, 2) NOT NULL,                   -- Giá món ăn
    discount DECIMAL(10, 2),                         -- Giảm giá (nếu có)
    total DECIMAL(10, 2) NOT NULL,                   -- Tổng giá sau khi tính
    orderID INT,                                     -- Khóa ngoại tới bảng orders
    menuItemID INT,                                  -- Khóa ngoại tới bảng menuItems
    FOREIGN KEY (orderID) REFERENCES orders(orderID) ON DELETE CASCADE,
    FOREIGN KEY (menuItemID) REFERENCES menuItems(menuItemID) ON DELETE CASCADE
);

-- Bảng bài viết (posts)
CREATE TABLE posts (
    postID INT AUTO_INCREMENT PRIMARY KEY,            -- ID bài viết
    title VARCHAR(255) NOT NULL,                      -- Tiêu đề bài viết
    content TEXT NOT NULL,                            -- Nội dung bài viết
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP     -- Ngày tạo bài viết
);

-- Bảng hình ảnh bài viết (postImages)
CREATE TABLE postImages (
    imageID INT AUTO_INCREMENT PRIMARY KEY,           -- ID hình ảnh
    imagePath VARCHAR(255) NOT NULL,                  -- Đường dẫn hình ảnh
    postID INT,                                       -- Khóa ngoại tới bảng posts
    FOREIGN KEY (postID) REFERENCES posts(postID) ON DELETE CASCADE
);

-- Bảng đánh giá dịch vụ (serviceReviews)
CREATE TABLE serviceReviews (
    serviceReviewID INT AUTO_INCREMENT PRIMARY KEY,                -- ID đánh giá
    rating INT CHECK (rating >= 1 AND rating <= 5),        -- Đánh giá từ 1 đến 5
    comment TEXT,                                          -- Nhận xét
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,         -- Ngày tạo đánh giá
    reviewType ENUM('order', 'table') NOT NULL,           -- Loại đánh giá: 'order' hoặc 'table'
    orderID INT DEFAULT NULL,                               -- Khóa ngoại tới bảng đơn hàng
    tableOrderID INT DEFAULT NULL,                          -- Khóa ngoại tới bảng đơn bàn
    customerID INT NOT NULL,                                -- Khóa ngoại tới bảng khách hàng
    FOREIGN KEY (customerID) REFERENCES customers(customerID) ON DELETE CASCADE,
    FOREIGN KEY (orderID) REFERENCES orders(orderID) ON DELETE CASCADE,
    FOREIGN KEY (tableOrderID) REFERENCES tableOrders(tableOrderID) ON DELETE CASCADE
);




-- Thêm dữ liệu mẫu vào bảng customers
-- Chèn thêm khách hàng

-- Chèn dữ liệu cho hai chi nhánh
INSERT INTO branches (branchName, address, branchPhone) 
VALUES 
('Main Branch', '123 Main St, Cityville', '1234000000'),
('North Branch', '456 North St, Townsville', '1234000001');



-- Thêm 20 bàn cho Main Branch
INSERT INTO tables (tableNumber, tableStatus, branchID) 
VALUES 
(1, 'open', 1),
(2, 'open', 1),
(3, 'open', 1),
(4, 'open', 1),
(5, 'open', 1),
(6, 'open', 1),
(7, 'open', 1),
(8, 'open', 1),
(9, 'open', 1),
(10, 'open', 1),
(11, 'close', 1),
(12, 'close', 1),
(13, 'close', 1),
(14, 'wait', 1),
(15, 'wait', 1),
(16, 'open', 1),
(17, 'open', 1),
(18, 'open', 1),
(19, 'open', 1),
(20, 'open', 1);

-- Thêm 30 bàn cho North Branch
INSERT INTO tables (tableNumber, tableStatus, branchID) 
VALUES 
(1, 'open', 2),
(2, 'open', 2),
(3, 'open', 2),
(4, 'open', 2),
(5, 'open', 2),
(6, 'open', 2),
(7, 'open', 2),
(8, 'open', 2),
(9, 'open', 2),
(10, 'open', 2),
(11, 'close', 2),
(12, 'close', 2),
(13, 'wait', 2),
(14, 'wait', 2),
(15, 'open', 2),
(16, 'open', 2),
(17, 'open', 2),
(18, 'open', 2),
(19, 'open', 2),
(20, 'open', 2),
(21, 'open', 2),
(22, 'open', 2),
(23, 'open', 2),
(24, 'open', 2),
(25, 'open', 2),
(26, 'open', 2),
(27, 'open', 2),
(28, 'open', 2),
(29, 'open', 2),
(30, 'open', 2);










-- Chèn dữ liệu vào bảng menu
INSERT INTO menus (menuName) VALUES 
('Món tráng miệng'),
('Salad'),
('Đồ uống'),
('Pizza'),
('Mì Ý'),
('Beefsteak');


-- Chèn dữ liệu vào bảng món ăn
INSERT INTO menuItems (itemName, description, price, image, menuID) VALUES
-- Món tráng miệng
('Bánh flan', 'Món tráng miệng truyền thống với lớp kem trứng mềm mịn và lớp caramel ngọt ngào.', 25000, 'menu/mon_trang_mieng/banh_flan.png', 1),
('Bánh Esterhazy', 'Bánh ngọt nổi tiếng từ Hungary, với nhiều lớp kem bơ hạt dẻ và lớp bột mỏng giòn tan, trang trí với những đường kẻ tinh tế.', 40000, 'menu/mon_trang_mieng/banh_esterhazy.png', 1),
('Kem socola', 'Kem vị socola đậm đà, ngọt ngào và mát lạnh, thích hợp để tráng miệng.', 30000, 'menu/mon_trang_mieng/kem_socola.png', 1),
('Kẹo cuộn', 'Loại kẹo cuộn nhiều lớp, ngọt ngào, bắt mắt, là món ăn vặt phổ biến và thú vị.', 10000, 'menu/mon_trang_mieng/keo_cuon.png', 1),
('Rau câu jelly', 'Thạch rau câu với hương vị trái cây đa dạng, mát lạnh và dai giòn.', 15000, 'menu/mon_trang_mieng/rau_cau_jelly.png', 1),

-- Salad
('Salad cá hồi', 'Cá Hồi | Rau mầm, rong biển, cà chua & rong biển tosaka đỏ-xanh kèm sốt mè rang.', 10.00, 'menu/salad/salad_ca_houi.png', 2),
('Salad nhiệt đới', 'Rong nho, Rau mầm, rong biển, cà chua | Bạch tuộc Nhật, Cá Trích Ép Trứng, Cá Hồi kèm sốt mè rang.', 9.00, 'menu/salad/salad_nhiet_doi.png', 2),
('Salad thanh cua', 'Thanh cua, Rong biển tosaka xanh - đỏ, rau mầm, rong biển, cà chua kèm sốt mè rang.', 9.00, 'menu/salad/salad_thanh_cua.png', 2),
('Salad da giòn', 'Da cá Hồi chiên giòn| Rong nho| Lolo xanh| Rau mầm, rong biển, cà chua & rong biển tosaka đỏ-xanh kèm sốt Salad.', 8.00, 'menu/salad/salad_da_gion.png', 2),
('Salad cá ngừ', 'Rong nho| Rau mầm, rong biển, cà chua | Cá Ngừ chín trộn mayo | Bơ trái kèm sốt mè rang.', 12.00, 'menu/salad/salad_ca_ngu.png', 2),
('Salad rong nho', 'Rong nho| Rau mầm, rong biển, cà chua & rong biển tosaka đỏ-xanh kèm sốt mè rang.', 7.00, 'menu/salad/salad_rong_nho.png', 2),
('Salad Cá Hồi & Bơ', 'Cá hồi| Bơ trái| Xà lách búp mỹ| Rong nho tosaka| Rong nho kèm sốt mè rang.', 13.00, 'menu/salad/salad_ca_houi_bo.png', 2),
('Salad Mix', 'Cá hồi| Cá trích ép trứng vàng & đỏ| Tôm thẻ| Bạch tuộc Nhật| Thanh cua| Sò đỏ Canada| Các loại rau mầm, rong biển, cà chua, xà lách kèm sốt mè rang.', 15.00, 'menu/salad/salad_mix.png', 2),

-- Đồ uống
('Coca', 'Nước giải khát có ga vị coca cola, được ưa chuộng trong các bữa tiệc hoặc dùng hàng ngày.', 15.00, 'menu/do_uong/coca.png', 3),
('Brandy - 10th Mountain éT 2012 Vail.co', 'Rượu brandy cao cấp, với hương vị trái cây đậm đà, được sản xuất tại Colorado, thích hợp cho những dịp đặc biệt.', 2500000, 'menu/do_uong/brandy_10th_mountain.png', 3),
('Nước Khoáng Vivant', 'Nước khoáng tự nhiên bổ sung khoáng chất, có ga nhẹ, mang lại cảm giác tươi mát.', 12.00, 'menu/do_uong/nuoc_khoang_vivant.png', 3),
('Rượu Whisky Ballantine - G82 255', 'Rượu whisky Scotch với hương vị mạnh mẽ, nồng ấm, thích hợp cho những bữa tiệc sang trọng.', 1200000, 'menu/do_uong/ruou_whisky_ballantines.png', 3),
('Rượu vang Passion - Reserva 750ml', 'Rượu vang đậm đà với hương vị trái cây chín mọng, thích hợp khi dùng kèm các món thịt.', 500000, 'menu/do_uong/ruou_vang_passion.png', 3),

-- Pizza
('Pizza Hải Sản Nhiệt Đới', 'Tôm, nghêu, mực cua, dứa với sốt Thousand Island.', 159000, 'menu/pizza/pizza_hai_san_nhiet_doi.png', 4),
('Pizza Thịt Xông Khói', 'Thịt giăm bông, thịt xông khói và hai loại rau của ớt xanh, cà chua.', 149000, 'menu/pizza/pizza_thit_xong_khoi.png', 4),
('Pizza Xúc Xích Ý', 'Xúc xích kiểu Ý trên nền sốt cà chua.', 139000, 'menu/pizza/pizza_xuc_xich_y.png', 4),
('Pizza Thịt Nguội & Nấm', 'Pizza giăm bông và nấm đem đến cho bạn những trải nghiệm thú vị.', 139000, 'menu/pizza/pizza_thit_nguoi_nam.png', 4),
('Pizza Hawaiian', 'Giăm bông, thịt muối và dứa.', 139000, 'menu/pizza/pizza_hawaiian.png', 4),
('Pizza Rau Củ', 'Hành, ớt chuông, nấm, dứa, cà chua.', 119000, 'menu/pizza/pizza_rau_cu.png', 4),
('Pizza Hải Sản Cao Cấp', 'Tôm, cua, mực và nghêu với sốt Marinara.', 159000, 'menu/pizza/pizza_hai_san_cao_cap.png', 4),
('Pizza Đặc Biệt', 'Xúc xích bò, giăm bông, thịt xông khói và cả thế giới rau phong phú.', 149000, 'menu/pizza/pizza_dac_biet.png', 4),
('Pizza Gà Nướng', 'Gà nướng, gà bơ tỏi và gà ướp sốt nấm.', 149000, 'menu/pizza/pizza_ga_nuong.png', 4),

-- Mì Ý
('Mì Ý Cay Hải Sản', 'Mỳ Ý rán với các loại hải sản tươi ngon cùng ớt và tỏi.', 139000, 'menu/mi_y/mi_y_cay_hai_san.png', 5),
('Mì Ý chay sốt kem tươi', 'Mỳ Ý chay thơm ngon với sốt kem và nấm.', 109000, 'menu/mi_y/mi_y_chay_sot_kem_tươi.png', 5),
('Mì Ý cay xúc xích', 'Mỳ Ý rán với xúc xích cay, thảo mộc, ngò gai và húng quế Ý.', 119000, 'menu/mi_y/mi_y_cay_xuc_xich.png', 5),
('Mì Ý Giăm Bông', 'Mỳ Ý, nấm và giăm bông được nấu cùng với sốt kem trắng.', 119000, 'menu/mi_y/mi_y_giam_bong.png', 5),
('Mì Ý Bò Bằm', 'Sốt thịt bò bằm đặc trưng kết hợp cùng mỳ Ý.', 139000, 'menu/mi_y/mi_y_bo_bam.png', 5),
('Mì Ý sốt kem cà chua', 'Sự tươi ngon của tôm kết hợp với sốt kem cà chua.', 139000, 'menu/mi_y/mi_y_sot_kem_ca_chua.png', 5),
('Mì Ý truyền thống', 'Mỳ Ý sốt cà chua truyền thống, hòa quyện với hương vị bơ.', 119000, 'menu/mi_y/mi_y_truyen_thong.png', 5),

-- Beefsteak
('Beefsteak Bò Mỹ', 'Bò mỹ được chế biến đặc biệt, tẩm gia vị hoàn hảo và nướng ở nhiệt độ thích hợp.', 279000, 'menu/beefsteak/beefsteak_bo_my.png', 6),
('Beefsteak Bò Úc', 'Bò Úc chọn lọc được nướng lửa than, giữ được độ mềm ngọt.', 299000, 'menu/beefsteak/beefsteak_bo_uc.png', 6),
('Beefsteak Bò Kobe', 'Beefsteak bò Kobe thượng hạng, với độ mềm ngọt và hương vị độc đáo.', 399000, 'menu/beefsteak/beefsteak_bo_kobe.png', 6),
('Beefsteak Chén Thơm', 'Beefsteak được nấu cùng các loại thảo mộc tự nhiên.', 350000, 'menu/beefsteak/beefsteak_chen_thom.png', 6),
('Beefsteak Thượng Hạng', 'Bò thượng hạng, nướng với độ chính xác cao, cho món ăn tuyệt hảo.', 399000, 'menu/beefsteak/beefsteak_thuong_hang.png', 6);
